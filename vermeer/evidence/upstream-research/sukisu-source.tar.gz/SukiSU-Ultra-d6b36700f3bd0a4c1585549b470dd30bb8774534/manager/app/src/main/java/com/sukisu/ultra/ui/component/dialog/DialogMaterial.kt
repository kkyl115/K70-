package com.sukisu.ultra.ui.component.dialog

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.LoadingIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.sukisu.ultra.data.registry.RegistryUrls
import com.sukisu.ultra.ui.component.markdown.MarkdownContent
import com.sukisu.ultra.ui.component.material.ExpressiveDialog

@Composable
fun LoadingDialogMaterial(
    showDialog: MutableState<Boolean>,
) {
    if (showDialog.value) {
        Dialog(
            onDismissRequest = { },
            // Keep the dialog non-dismissible
            properties = DialogProperties(
                dismissOnClickOutside = false,
                dismissOnBackPress = false,
            )
        ) {
            Surface(
                modifier = Modifier.size(100.dp), shape = MaterialTheme.shapes.extraLarge
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                ) {
                    LoadingIndicator()
                }
            }
        }
    }
}

@Composable
fun ConfirmDialogMaterial(
    visuals: ConfirmDialogVisuals,
    confirm: () -> Unit,
    dismiss: () -> Unit,
    showDialog: MutableState<Boolean>
) {
    if (showDialog.value) {
        ExpressiveDialog(
            onDismissRequest = {
                dismiss()
                showDialog.value = false
            },
            title = { Text(visuals.title) },
            text = visuals.content?.let { content ->
                {
                    when {
                        // Registry content (and any HTML, which only comes from the registry) is rendered locked down.
                    visuals.isRestricted || visuals.isHtml -> MarkdownContent(
                        content = content,
                        isMarkdown = !visuals.isHtml,
                        restrictedBaseUrl = RegistryUrls.DEFAULT_BASE_URL,
                    )
                    visuals.isMarkdown -> MarkdownContent(content = content, isMarkdown = true)
                    else -> Text(text = content)
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        confirm()
                        showDialog.value = false
                    }
                ) {
                    Text(visuals.confirm ?: stringResource(id = android.R.string.ok))
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        dismiss()
                        showDialog.value = false
                    }
                ) {
                    Text(visuals.dismiss ?: stringResource(id = android.R.string.cancel))
                }
            }
        )
    }
}
