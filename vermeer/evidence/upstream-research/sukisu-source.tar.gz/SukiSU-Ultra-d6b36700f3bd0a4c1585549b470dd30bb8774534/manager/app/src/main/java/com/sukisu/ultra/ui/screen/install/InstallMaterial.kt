package com.sukisu.ultra.ui.screen.install

import  androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.DriveFileMove
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.SdStorage
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LargeFlexibleTopAppBar
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.TopAppBarScrollBehavior
import androidx.compose.material3.rememberTopAppBarState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.sukisu.ultra.R
import com.sukisu.ultra.getKernelVersion
import com.sukisu.ultra.ui.component.dialog.rememberConfirmDialog
import com.sukisu.ultra.ui.component.material.ExpressiveScaffold
import com.sukisu.ultra.ui.component.material.SegmentedCheckboxItem
import com.sukisu.ultra.ui.component.material.IconTile
import com.sukisu.ultra.ui.component.material.SegmentedColumn
import com.sukisu.ultra.ui.component.material.SegmentedDropdownItem
import com.sukisu.ultra.ui.component.material.SegmentedListItem
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import com.sukisu.ultra.ui.component.material.SegmentedTextField
import com.sukisu.ultra.ui.component.material.SnackBarHost
import com.sukisu.ultra.ui.component.material.TopBarBackButton
import com.sukisu.ultra.ui.component.material.expressiveTopAppBarColors
import com.sukisu.ultra.ui.util.LkmSelection
import com.sukisu.ultra.ui.util.isAbDevice

/**
 * @author weishu
 * @date 2024/3/12.
 */
@Composable
internal fun InstallScreenMaterial(
    uiState: InstallUiState,
    actions: InstallScreenActions,
    snackBarHost: SnackbarHostState,
) {
    val scrollBehavior = TopAppBarDefaults.exitUntilCollapsedScrollBehavior(rememberTopAppBarState())

    val isAbDevice by produceState(initialValue = false) {
        value = isAbDevice()
    }
    val isGkiDevice by produceState(initialValue = false) {
        value = getKernelVersion().isGKI()
    }

    LaunchedEffect(Unit) {
        scrollBehavior.state.heightOffset = scrollBehavior.state.heightOffsetLimit
    }

    ExpressiveScaffold(
        topBar = {
            TopBar(
                onBack = actions.onBack,
                scrollBehavior = scrollBehavior,
            )
        },
        snackbarHost = { SnackBarHost(hostState = snackBarHost, modifier = Modifier.safeDrawingPadding()) },
        contentWindowInsets = WindowInsets.safeDrawing.only(WindowInsetsSides.Top + WindowInsetsSides.Horizontal)
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxHeight()
                .nestedScroll(scrollBehavior.nestedScrollConnection)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(13.dp)
        ) {
            SelectInstallMethod(
                state = uiState,
                onSelected = actions.onSelectMethod,
                onDownloadFile = actions.onDownloadFile,
                onSelectBootImage = actions.onSelectBootImage,
            )

            SegmentedColumn(
                modifier = Modifier.padding(horizontal = 16.dp),
                content = buildList {
                    val isDownload = uiState.installMethod is InstallMethod.DownloadFile
                    val partitionItems = if (isDownload) {
                        uiState.remoteDisplayPartitions
                    } else {
                        uiState.displayPartitions
                    }
                    val partitionIndex = if (isDownload) {
                        uiState.remotePartitionSelectionIndex
                    } else {
                        uiState.partitionSelectionIndex
                    }
                    if (partitionItems.isNotEmpty() && uiState.installMethod !is InstallMethod.HorizonKernel) add {
                        SegmentedDropdownItem(
                            enabled = uiState.canSelectPartition,
                            items = partitionItems,
                            selectedIndex = partitionIndex,
                            title = if (isDownload) {
                                stringResource(R.string.install_select_partition)
                            } else {
                                "${stringResource(R.string.install_select_partition)} (${uiState.slotSuffix})"
                            },
                            onItemSelected = actions.onSelectPartition,
                            icon = Icons.Filled.Edit
                        )
                    }
                    if (uiState.canForceBackup && uiState.installMethod !is InstallMethod.HorizonKernel) add {
                        SegmentedCheckboxItem(
                            title = stringResource(R.string.install_force_backup),
                            summary = stringResource(R.string.install_force_backup_summary),
                            onCheckedChange = actions.onSelectForceBackup,
                            checked = uiState.forceBackup,
                        )
                    }
                    if (isGkiDevice && uiState.installMethod !is InstallMethod.HorizonKernel) add {
                        SegmentedListItem(
                            leadingContent = {
                                IconTile(Icons.AutoMirrored.Filled.DriveFileMove, null)
                            },
                            headlineContent = { Text(stringResource(R.string.install_upload_lkm_file)) },
                            supportingContent = {
                                (uiState.lkmSelection as? LkmSelection.LkmUri)?.let {
                                    Text(
                                        stringResource(
                                            R.string.selected_lkm,
                                            it.uri.lastPathSegment ?: "(file)"
                                        )
                                    )
                                }
                            },
                            trailingContent = {
                                if (uiState.lkmSelection is LkmSelection.LkmUri) {
                                    IconButton(onClick = actions.onClearLkm) {
                                        Icon(
                                            Icons.Filled.Close,
                                            contentDescription = stringResource(android.R.string.cancel)
                                        )
                                    }
                                } else {
                                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null)
                                }
                            },
                            onClick = actions.onUploadLkm
                        )
                    }
                }
            )
            SegmentedColumn(
                modifier = Modifier.padding(horizontal = 16.dp),
            ) {
                item {
                    val rotationState by animateFloatAsState(
                        targetValue = if (uiState.advancedOptionsShown) 180f else 0f,
                        label = "RotationAnimation"
                    )
                    SegmentedListItem(
                        headlineContent = { Text(stringResource(R.string.advanced_options)) },
                        trailingContent = {
                            Icon(
                                imageVector = Icons.Filled.ExpandMore,
                                contentDescription = stringResource(R.string.expand),
                                modifier = Modifier.graphicsLayer { rotationZ = rotationState }
                            )
                        },
                        onClick = actions.onAdvancedOptionsClicked
                    )
                }
                item(visible = uiState.advancedOptionsShown) {
                    SegmentedCheckboxItem(
                        title = stringResource(id = R.string.allow_shell),
                        summary = stringResource(id = R.string.allow_shell_summary),
                        checked = uiState.allowShell,
                        onCheckedChange = actions.onSelectAllowShell,
                    )
                }
                item(visible = uiState.advancedOptionsShown) {
                    SegmentedCheckboxItem(
                        title = stringResource(id = R.string.enable_adb),
                        summary = stringResource(id = R.string.enable_adb_summary),
                        checked = uiState.enableAdb,
                        onCheckedChange = actions.onSelectEnableAdb,
                    )
                }
                item(visible = uiState.advancedOptionsShown) {
                    SegmentedCheckboxItem(
                        title = stringResource(id = R.string.install_block_modules),
                        summary = stringResource(id = R.string.install_block_modules_warning),
                        checked = uiState.blockModulesEnabled,
                        onCheckedChange = actions.onSelectBlockModules,
                    )
                }
                item(visible = uiState.advancedOptionsShown && uiState.blockModulesEnabled) {
                    OutlinedTextField(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        value = uiState.blockModules,
                        onValueChange = actions.onBlockModulesChange,
                        label = { Text(stringResource(id = R.string.install_block_modules_list)) },
                        supportingText = {
                            Text(
                                stringResource(
                                    if (uiState.blockModulesValid) {
                                        R.string.install_block_modules_summary
                                    } else {
                                        R.string.install_block_modules_invalid
                                    }
                                )
                            )
                        },
                        isError = !uiState.blockModulesValid,
                        singleLine = true,
                    )
                }
                item(visible = uiState.advancedOptionsShown) {
                    SegmentedCheckboxItem(
                        title = stringResource(id = R.string.kernel_spoof),
                        summary = stringResource(id = R.string.kernel_spoof_summary),
                        checked = uiState.spoofEnabled,
                        onCheckedChange = actions.onSpoofEnabledChange,
                    )
                }
                item(visible = uiState.advancedOptionsShown && uiState.spoofEnabled) {
                    SegmentedTextField(
                        value = uiState.spoofRelease,
                        onValueChange = actions.onSpoofReleaseChange,
                        label = stringResource(R.string.kernel_spoof_release),
                        singleLine = true
                    )
                }
                item(visible = uiState.advancedOptionsShown && uiState.spoofEnabled) {
                    SegmentedTextField(
                        value = uiState.spoofVersion,
                        onValueChange = actions.onSpoofVersionChange,
                        label = stringResource(R.string.kernel_spoof_version),
                        singleLine = true
                    )
                }
            }
            // AnyKernel3 刷写
            (uiState.installMethod as? InstallMethod.HorizonKernel)?.let { method ->
                SegmentedColumn(
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 13.dp),
                ) {
                    if (isAbDevice && method.slot != null) {
                        item {
                            SegmentedListItem(
                                onClick = { actions.onReopenSlotDialog(method) },
                                leadingContent = {
                                    IconTile(Icons.Filled.SdStorage, null)
                                },
                                headlineContent = {
                                    Text(
                                        stringResource(
                                            id = R.string.selected_slot,
                                            if (method.slot == "a") stringResource(id = R.string.slot_a)
                                            else stringResource(id = R.string.slot_b)
                                        )
                                    )
                                },
                                trailingContent = {
                                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null)
                                }
                            )
                        }
                    }
                }
            }
            Button(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                enabled = uiState.installMethod != null && uiState.blockModulesValid,
                onClick = actions.onNext
            ) { Text(stringResource(R.string.install_next)) }
        }
    }
}

@Composable
private fun SelectInstallMethod(
    state: InstallUiState,
    onSelected: (InstallMethod) -> Unit,
    onDownloadFile: () -> Unit,
    onSelectBootImage: (InstallMethod) -> Unit,
) {
    val confirmDialog = rememberConfirmDialog(
        onConfirm = {
            onSelected(InstallMethod.DirectInstallToInactiveSlot)
        },
        onDismiss = null
    )
    val dialogTitle = stringResource(android.R.string.dialog_alert_title)
    val dialogContent = stringResource(R.string.install_inactive_slot_warning)

    val onClick = { option: InstallMethod ->
        when (option) {
            is InstallMethod.SelectFile -> onSelectBootImage(option)
            is InstallMethod.HorizonKernel -> onSelectBootImage(option)
            is InstallMethod.DownloadFile -> onDownloadFile()
            is InstallMethod.DirectInstall -> onSelected(option)
            is InstallMethod.DirectInstallToInactiveSlot -> confirmDialog.showConfirm(dialogTitle, dialogContent)
        }
    }

    val haptic = LocalHapticFeedback.current
    key(state.installMethodOptions.size) {
        Column(
            modifier = Modifier
                .padding(horizontal = 16.dp)
                .selectableGroup(),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            state.installMethodOptions.forEach { option ->
                InstallMethodCard(
                    title = stringResource(option.label),
                    summary = option.summary,
                    selected = state.installMethod?.let { option::class == it::class } ?: false,
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.VirtualKey)
                        onClick(option)
                    },
                )
            }
        }
    }
}

@Composable
private fun InstallMethodCard(
    title: String,
    summary: String?,
    selected: Boolean,
    onClick: () -> Unit,
) {
    val borderColor by animateColorAsState(
        if (selected) MaterialTheme.colorScheme.primary else Color.Transparent,
        label = "install_method_border"
    )
    Surface(
        selected = selected,
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        color = if (selected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceBright,
        border = BorderStroke(2.dp, borderColor),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            RadioButton(selected = selected, onClick = null)
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                )
                if (!summary.isNullOrBlank()) {
                    Text(
                        text = summary,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@Composable
private fun TopBar(
    onBack: () -> Unit = {},
    scrollBehavior: TopAppBarScrollBehavior? = null
) {
    LargeFlexibleTopAppBar(
        title = { Text(stringResource(R.string.install)) },
        navigationIcon = {
            TopBarBackButton(onClick = onBack)
        },
        colors = expressiveTopAppBarColors(),
        windowInsets = WindowInsets.safeDrawing.only(WindowInsetsSides.Top + WindowInsetsSides.Horizontal),
        scrollBehavior = scrollBehavior
    )
}
